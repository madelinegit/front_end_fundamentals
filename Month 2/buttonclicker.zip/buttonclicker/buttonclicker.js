console.log("javascript")

function liked() {
    alert('liked')
}

function logout() {
    var loginbtn = document.getElementById("logout-id")
    loginbtn.innerText="Logout"
}

function definition() {
var defbutton = document.querySelector(".defbutton")
defbutton.remove()
}

