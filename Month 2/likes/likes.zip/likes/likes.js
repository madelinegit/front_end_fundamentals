console.log("javascript")

function like() {
    alert('Liked')
}

var count=0
var likeCount=document.querySelector(".likeCount")
function liked() {
    count++
    console.log(count)
    likeCount.innerText=count
}
