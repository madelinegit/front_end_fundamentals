console.log("javascript")

function alerts() {
    alert('Loading weather report...')
    }

let iaccept = document.querySelector(".cookie")
function accept() {
    iaccept.remove() 
}    