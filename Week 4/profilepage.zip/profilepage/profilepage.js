console.log("javascript")

var count = 2
var countTotal = 500
var request = document.querySelector(".request-list")
var counter = document.querySelector(".counter")
function decline() {
    request.remove()
    count--
    countTotal++
    console.log(count)
    counter.innerText = count
    console.log(countTotal)
    counterTotal.innerText = countTotal
}

var count = 2
var countTotal = 500
var request2 = document.querySelector(".request-list2")
var counter = document.querySelector(".counter")
function decline2() {
    request2.remove()
    count--
    countTotal++
    console.log(count)
    counter.innerText = count
    console.log(countTotal)
    counterTotal.innerText = countTotal
}

var count = 2
var countTotal = 500
var request = document.querySelector(".request-list")
var counter = document.querySelector(".counter")
var counterTotal = document.querySelector(".counter-total")
function accept() {
    request.remove()
    count--
    countTotal++
    console.log(count)
    counter.innerText = count
    console.log(countTotal)
    counterTotal.innerText = countTotal
}

var count = 2
var countTotal = 500
var request2 = document.querySelector(".request-list2")
var counter = document.querySelector(".counter")
var counterTotal = document.querySelector(".counter-total")
function accept2() {
    request2.remove()
    count--
    countTotal++
    console.log(count)
    counter.innerText = count
    console.log(countTotal)
    counterTotal.innerText = countTotal
}

// var newName = document.querySelector("newname")
var newName = document.querySelector(".editname")
function nameChange() {
    // var editName = document.querySelector("name")
    newName.innerText="Madeline Gall"
    console.log(nameChange)
    // console.log(newName)
}







// var = count 
        // count1--
//         console.log(count1)
//         count.inntertext=result 



// function requests(id) {
//     var request = document.querySelector("#request-list1")
//         if (id == 1) {
//         request.remove()
//         }
//     }
//     
    

// // function accept()
// function requests2(id) {
//     var request = document.querySelector("#request-list2")
//     if (id == 2) {
//     request.remove()
//     }
//     }



// var count=2
// var result=document.getElementById("count")






/* <script>
            $('body').contents().filter(function(){
            return this.nodeType != 1;
            }).remove();
        </script> */

// <ul class="requests" onclick="requests()">  </ul>

// would make .img-accept a global variable and then call on 


// notes on counting
