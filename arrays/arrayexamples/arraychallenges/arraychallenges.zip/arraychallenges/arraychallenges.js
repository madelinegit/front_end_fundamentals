// function alwaysHungry(arr) {
//     // your code here 
// }

// alwaysHungry([3.14, "food", "pie", true, "food"]);
// // this should console log "yummy", "yummy"
// alwaysHungry([4, 1, 5, 7, 2]);
// // this should console log "I'm hungry"

// var message = 'food';
// function alwaysHungry(arr) {
//     if (message='food');
//     console.log('yummy')
// }


// alwaysHungry([3.14, "food", "pie", true, "food"]); {
//     while(message='food');
//     console.log('yummy');
// }

// function alwaysHungry(arr) {
//     arr=('food');
//     console.log('yummy')
//     }
// function alwaysHungry((3.14, ["food"], ["pie"], true, ["food"]()); {

// }
// console.log()
// while (arr == "food");
//     console.log("yummy")


function alwaysHungry(arr) {
    var banana = 0;
    for (let e of arr) {
        if (e =="food"){ 
            console.log("yummy")
            banana++
        }
    }
    if (banana == 0) {
        console.log("I'm Hungry")
    }
}

alwaysHungry([3.14, "food", "pie", true, "food"]);

alwaysHungry([4, 1, 5, 7, 2])


// this should console log "yummy", "yummy"
// this should console log "I'm hungry"

