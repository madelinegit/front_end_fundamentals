// function betterThanAverage(arr) {
//     var sum = 0;
//     // calculate the average
//     var count = 0
//     // count how many values are greater than the average
//     return count;
// }
// var result = betterThanAverage([6, 8, 3, 10, -2, 5, 9]);
// console.log(result); // we expect back 4




// function betterThanAverage(arr) {
//     var sum = 0;
//         for (let sum of sums);
//             avg= (sum/sums.length);
//     console.log(avg)
//     var count = 0
//         if (sum<avg);
//     return count;
//     console.log(count.length+1)
// }
// var result = betterThanAverage([6, 8, 3, 10, -2, 5, 9]);
// console.log(result); // we expect back 4



function betterThanAverage(arr) {
    var result = 0
    var count = 0
    for (let e of arr){
        result+=e
    }
    result = result/arr.length
        for (let e of arr) {
            if (e>result){
            count ++
            }
        }
    return(count)
    }

console.log(betterThanAverage([6, 8, 3, 10, -2, 5, 9]))

// betterThanAverage([6, 8, 3, 10, -2, 5, 9]);

// console.log(result);

    //         avg= ();
    // console.log(avg)
    // var count = 0
    //     if (sum<avg);
    // return count;
    // console.log(count.length+1)
// }
// var result = betterThanAverage([6, 8, 3, 10, -2, 5, 9]);
// console.log(result); // we expect back 4



//pre bootcamp  conditionals, and https://stackoverflow.com/questions/29544371/finding-the-average-of-an-array-using-js

// function betterThanAverage(arr) {
//     var sum = 0;
//     for (var i in betterThanAverage) {
//         sum+=betterThanAverage[i];
//     }
// }

//     var count = 0 {
//     if 
//         // count how many values are greated than the average
//     }
//     return count;
// // }
// var result = betterThanAverage([6, 8, 3, 10, -2, 5, 9]);
// console.log(result); // we expect back 4





// function betterThanAverage(arr) {
//     var sum = 0;
//     // calculate the average
//     var count = 0
//     // count how many values are greated than the average
//     return count;
// }
// var result = betterThanAverage([6, 8, 3, 10, -2, 5, 9]);
// console.log(result); // we expect back 4